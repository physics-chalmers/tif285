This IPython notebook LinearRegression.ipynb does not require any additional
programs.
